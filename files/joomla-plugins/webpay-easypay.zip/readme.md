﻿# Virtue Mart 3 . Plugins for EasyPay and WebPay payment systems
Reqestion:
- Joomla 3
- Virtue Mart 3

Virtue Mart payment plugins for Belarussian payment systems "Web Pay" and "Easy Pay".  

Installation:
- copy folders "webpay" and "easypay" form /plugins/vmpayment/ in your one.
- copy or move languages files form folder "webpay" to your languages folders
  (joomla-root/language/en-GB/ and joomla-root/language/ru-RU/).

Plugin settings:
- Shop title
- Shop ID
- Payment Url
- SecretKey (Secret word to signature setting)

Сurrency exchange rate is set by Virtue Mart.

The signature is unique for each transaction and transmitted in encrypted form.

Each transaction is logged in database table. Run "webpay.sql"  to create the table.
